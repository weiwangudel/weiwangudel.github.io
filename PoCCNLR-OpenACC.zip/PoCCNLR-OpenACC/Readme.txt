1. Before you try, pelase add path of the bin subfolder to environment variable PATH 
   for exmaple, if this folder is at the desktop and named WinPoCC-Standalone
   then, add
   c:\users\YOUR_USER_NAME\Desktop\WinPoCC-Standalone\bin to the $PATH variable
   
by
Method A: 
    set PATH c:\users\YOUR_USER_NAME\Desktop\WinPoCC-Standalone\bin
or
Method B:
   1) click windows START icon
   2) Right click "computer" 
		choose property
   3) Choose "Advanced system settings"
   4) click "Environment Variables" near the bottom
   5) edit PATH in User variables
	-- add this directory and end with a ";" (no quote).