1@ // JohnOut.cpp : Defines the entry point for the console application.
2@ //
3@ 
4@ 
5@ 
6@ #include <stdio.h>
7@ //#include <unistd.h>
8@ #include <string.h>
9@ #include <math.h>
10@ 
11@ //#include "instrument.h"
12@ 
13@ #include "gentrace.h"
14@ extern FILE* fid;
15@ 
16@ /* Default problem size. */
17@ #ifndef N
18@ # define N 100
19@ #endif
20@ 
21@ /* Default data type is double. */
22@ #ifndef DATA_TYPE
23@ # define DATA_TYPE double
24@ #endif
25@ 
26@ 
27@ 
28@ /* Array declaration. Enable malloc if POLYBENCH_TEST_MALLOC. */
29@ DATA_TYPE alpha;
30@ DATA_TYPE beta;
31@ #ifndef POLYBENCH_TEST_MALLOC
32@ DATA_TYPE A[N][N];
33@ DATA_TYPE B[N][N];
34@ DATA_TYPE x[N];
35@ DATA_TYPE u1[N];
36@ DATA_TYPE u2[N];
37@ DATA_TYPE v2[N];
38@ DATA_TYPE v1[N];
39@ DATA_TYPE w[N];
40@ DATA_TYPE y[N];
41@ DATA_TYPE z[N];
42@ #else
43@ DATA_TYPE** A = (DATA_TYPE**)malloc(N * sizeof(DATA_TYPE*));
44@ DATA_TYPE** B = (DATA_TYPE**)malloc(N * sizeof(DATA_TYPE*));
45@ DATA_TYPE* x = (DATA_TYPE*)malloc(N * sizeof(DATA_TYPE));
46@ DATA_TYPE* u1 = (DATA_TYPE*)malloc(N * sizeof(DATA_TYPE));
47@ DATA_TYPE* u2 = (DATA_TYPE*)malloc(N * sizeof(DATA_TYPE));
48@ DATA_TYPE* v1 = (DATA_TYPE*)malloc(N * sizeof(DATA_TYPE));
49@ DATA_TYPE* v2 = (DATA_TYPE*)malloc(N * sizeof(DATA_TYPE));
50@ DATA_TYPE* w = (DATA_TYPE*)malloc(N * sizeof(DATA_TYPE));
51@ DATA_TYPE* y = (DATA_TYPE*)malloc(N * sizeof(DATA_TYPE));
52@ DATA_TYPE* z = (DATA_TYPE*)malloc(N * sizeof(DATA_TYPE));
53@ {
54@   int i;
55@   for (i = 0; i < N; ++i)
56@     {
57@       (A[(i)]) = (DATA_TYPE*)malloc((N) * sizeof(DATA_TYPE));
58@       (B[(i)]) = (DATA_TYPE*)malloc((N) * sizeof(DATA_TYPE));
59@     }
60@ }
61@ #endif
62@ 
63@ inline
64@ void init_array()
65@ {
66@   int i, j;
67@ 
68@  TnsMemWr(alpha) = TnsMemC(43532);	fprintf(fid, "Line%i \n", __LINE__);
69@  TnsMemWr(beta) = TnsMemC(12313);		fprintf(fid, "Line%i \n", __LINE__);
70@   for (i = 0; i < N; i++)
71@     {
72@       TnsMemWr(u1[(i)]) = TnsMemIter(i);		fprintf(fid, "Line%i \n", __LINE__);
73@       TnsMemWr(u2[(i)]) = (TnsMemIter(i)+TnsMemC(1))/TnsMemC(N)/TnsMemC(2.0);	fprintf(fid, "Line%i \n", __LINE__);
74@       TnsMemWr(v1[(i)]) = (TnsMemIter(i)+TnsMemC(1))/TnsMemC(N)/TnsMemC(4.0);	fprintf(fid, "Line%i \n", __LINE__);
75@       TnsMemWr(v2[(i)]) = (TnsMemIter(i)+TnsMemC(1))/TnsMemC(N)/TnsMemC(6.0);	fprintf(fid, "Line%i \n", __LINE__);
76@       TnsMemWr(y[(i)]) = (TnsMemIter(i)+TnsMemC(1))/TnsMemC(N)/TnsMemC(8.0); 	fprintf(fid, "Line%i \n", __LINE__);
77@       TnsMemWr(z[(i)]) = (TnsMemIter(i)+TnsMemC(1))/TnsMemC(N)/TnsMemC(9.0); 	fprintf(fid, "Line%i \n", __LINE__);
78@       TnsMemWr(x[(i)]) = TnsMemC(0.0);		fprintf(fid, "Line%i \n", __LINE__);
79@       TnsMemWr(w[(i)]) = TnsMemC(0.0);			fprintf(fid, "Line%i \n", __LINE__);
80@       for (j = 0; j < N; j++)
81@ 	  {
82@ 		TnsMemWr(A[(i)][(j)]) = (((DATA_TYPE) TnsMemIter(i))*TnsMemIter(j)) / TnsMemC(N); fprintf(fid, "\n");  fprintf(fid, "Line%i \n", __LINE__);	
83@ 	  }
84@     }
85@ }
86@ 
87@ /* Define the live-out variables. Code is not executed unless
88@    POLYBENCH_DUMP_ARRAYS is defined. */
89@ inline
90@ void print_array(int argc, char** argv)
91@ {
92@   int i, j;
93@ #ifndef POLYBENCH_DUMP_ARRAYS
94@  
95@ #endif
96@     {
97@       for (i = 0; i < N; i++) {
98@ 	fprintf(stderr, "%0.2lf ", w[i]);
99@ 	if (i%80 == 20) fprintf(stderr, "\n");
100@       }
101@       fprintf(stderr, "\n");
102@     }
103@ }
104@ 
105@ 
106@ int main(int argc, char** argv)
107@ {
108@ 	fid = fopen("memory.txt", "w+t");
109@ 
110@   int i, j;
111@   int n = (N);
112@ 
113@   /* Initialize array. */
114@   init_array();
115@ 
116@   /* Start timer. */
117@   //polybench_start_instruments;
118@ 
119@ #pragma scop
120@ #pragma live-out w
121@ 
122@   for (i = 0; i < N; i++)
123@     for (j = 0; j < N; j++)
124@ 	{
125@     TnsMemWr(A[(i)][(j)]) = TnsMem(A[(i)][(j)]) + TnsMem(u1[(i)]) * TnsMem(v1[(j)]) + TnsMem(u2[(i)]) * TnsMem(v2[(j)]);	fprintf(fid, "Line%i \n", __LINE__);
126@ 	}
127@ 
128@   for (i = 0; i < N; i++)
129@     for (j = 0; j < N; j++)
130@ 	{
131@       TnsMemWr(x[(i)]) = TnsMem(x[(i)]) + TnsMem(beta) * TnsMem(A[(j)][(i)]) * TnsMem(y[(j)]); fprintf(fid, "Line%i \n" , __LINE__);
132@ 	}
133@ 
134@   for (i = 0; i < N; i++)
135@   {
136@     TnsMemWr(x[(i)]) = TnsMem(x[(i)]) + TnsMem(z[(i)]);	fprintf(fid, "Line%i \n" , __LINE__);
137@   }
138@ 
139@   for (i = 0; i < N; i++)
140@     for (j = 0; j < N; j++)
141@ 	{
142@   TnsMemWr(w[(i)]) = TnsMem(w[(i)]) +  TnsMem(alpha) * TnsMem(A[(i)][(j)]) * TnsMem(x[(j)]);fprintf(fid, "Line%i \n" , __LINE__);
143@ 	}
144@ 
145@ #pragma endscop
146@ 
147@   /* Stop and print timer. */
148@   //polybench_stop_instruments;
149@   //polybench_print_instruments;
150@ 
151@   print_array(argc, argv);
152@ 
153@   fclose(fid);
154@   return 0;
155@ }
